package ui;

/*
 * Any action the user chooses with the UI
 */
public interface Action
{
	public String name();
}
