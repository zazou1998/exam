package ui.menu.exception;

public class MenuNotFound extends Exception
{
	public MenuNotFound(String message)
	{
		super(message);
	}
}
