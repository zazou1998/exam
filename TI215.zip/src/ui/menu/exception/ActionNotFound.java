package ui.menu.exception;

public class ActionNotFound extends Exception
{
	public ActionNotFound(String string)
	{
		super(string);
	}
}
