package ui;

/*
 * General program control actions
 */
public enum ControlAction implements Action
{
	EXIT; // Exit program
}
