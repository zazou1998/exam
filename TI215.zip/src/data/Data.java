package data;

/*
 * Use this object (and others) to store information about the devices, networks and rooms
 */
public class Data
{

}
