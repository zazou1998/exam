package manager;

import data.Data;
import ui.UI;

public interface ActionMethod
{
	void execute(UI ui, Data data);
}