package manager.exception;

public class ManagerMethodNotFound extends Exception
{
	public ManagerMethodNotFound(String message)
	{
		super(message);
	}
}
